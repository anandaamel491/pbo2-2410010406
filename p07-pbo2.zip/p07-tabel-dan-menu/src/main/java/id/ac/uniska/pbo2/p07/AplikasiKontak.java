package id.ac.uniska.pbo2.p07;

import com.formdev.flatlaf.FlatLightLaf;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.table.TableRowSorter;

/**
 * Aplikasi Daftar Kontak: JTable dengan AbstractTableModel, menu, dan dialog modal.
 */
public class AplikasiKontak extends javax.swing.JFrame {

    // Dibuat sebelum initComponents() karena dipakai sebagai model JTable
    private final KontakTableModel model = new KontakTableModel();
    private final TableRowSorter<KontakTableModel> sorter = new TableRowSorter<>(model);

    /** Membuat form baru. */
    public AplikasiKontak() {
        initComponents();

        // Kode tambahan yang tidak tersedia di jendela Properties
        cariField.putClientProperty("JTextField.placeholderText", "Cari nama, telepon, email");
        kontakTable.setRowSorter(sorter); // klik judul kolom untuk mengurutkan
        kontakTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        kontakTable.getColumnModel().getColumn(0).setPreferredWidth(170);
        kontakTable.getColumnModel().getColumn(2).setPreferredWidth(200);

        // Tombol Ubah dan Hapus hanya aktif jika ada baris yang dipilih
        kontakTable.getSelectionModel().addListSelectionListener(e -> perbaruiTombol());

        isiContoh();
        perbaruiTombol();
        perbaruiStatus();
        setSize(780, 460);
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        atasPanel = new javax.swing.JPanel();
        tombolPanel = new javax.swing.JPanel();
        tambahButton = new javax.swing.JButton();
        ubahButton = new javax.swing.JButton();
        hapusButton = new javax.swing.JButton();
        cariField = new javax.swing.JTextField();
        tabelPanel = new javax.swing.JPanel();
        tabelScroll = new javax.swing.JScrollPane();
        kontakTable = new javax.swing.JTable();
        statusLabel = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        keluarItem = new javax.swing.JMenuItem();
        kontakMenu = new javax.swing.JMenu();
        tambahItem = new javax.swing.JMenuItem();
        ubahItem = new javax.swing.JMenuItem();
        kontakSeparator = new javax.swing.JPopupMenu.Separator();
        hapusItem = new javax.swing.JMenuItem();
        bantuanMenu = new javax.swing.JMenu();
        tentangItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Daftar Kontak");

        atasPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 4, 8, 12));
        atasPanel.setLayout(new java.awt.BorderLayout(8, 0));

        tombolPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 8, 0));

        tambahButton.setText("Tambah");
        tambahButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahButtonActionPerformed(evt);
            }
        });
        tombolPanel.add(tambahButton);

        ubahButton.setText("Ubah");
        ubahButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ubahButtonActionPerformed(evt);
            }
        });
        tombolPanel.add(ubahButton);

        hapusButton.setText("Hapus");
        hapusButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusButtonActionPerformed(evt);
            }
        });
        tombolPanel.add(hapusButton);

        atasPanel.add(tombolPanel, java.awt.BorderLayout.WEST);

        cariField.setColumns(20);
        cariField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cariFieldKeyReleased(evt);
            }
        });
        atasPanel.add(cariField, java.awt.BorderLayout.EAST);

        getContentPane().add(atasPanel, java.awt.BorderLayout.NORTH);

        tabelPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 12, 0, 12));
        tabelPanel.setLayout(new java.awt.BorderLayout());


        kontakTable.setModel(model);
        kontakTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                kontakTableMouseClicked(evt);
            }
        });
        tabelScroll.setViewportView(kontakTable);

        tabelPanel.add(tabelScroll, java.awt.BorderLayout.CENTER);

        getContentPane().add(tabelPanel, java.awt.BorderLayout.CENTER);

        statusLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(6, 12, 8, 12));
        statusLabel.setText(" ");
        getContentPane().add(statusLabel, java.awt.BorderLayout.SOUTH);


        fileMenu.setMnemonic('F');
        fileMenu.setText("File");

        keluarItem.setText("Keluar");
        keluarItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keluarItemActionPerformed(evt);
            }
        });
        fileMenu.add(keluarItem);

        menuBar.add(fileMenu);

        kontakMenu.setMnemonic('K');
        kontakMenu.setText("Kontak");

        tambahItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        tambahItem.setText("Tambah");
        tambahItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahItemActionPerformed(evt);
            }
        });
        kontakMenu.add(tambahItem);

        ubahItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        ubahItem.setText("Ubah");
        ubahItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ubahItemActionPerformed(evt);
            }
        });
        kontakMenu.add(ubahItem);

        kontakMenu.add(kontakSeparator);

        hapusItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        hapusItem.setText("Hapus");
        hapusItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusItemActionPerformed(evt);
            }
        });
        kontakMenu.add(hapusItem);

        menuBar.add(kontakMenu);

        bantuanMenu.setMnemonic('B');
        bantuanMenu.setText("Bantuan");

        tentangItem.setText("Tentang");
        tentangItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tentangItemActionPerformed(evt);
            }
        });
        bantuanMenu.add(tentangItem);

        menuBar.add(bantuanMenu);

        setJMenuBar(menuBar);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tambahButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahButtonActionPerformed
        tambah();
    }//GEN-LAST:event_tambahButtonActionPerformed

    private void ubahButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ubahButtonActionPerformed
        ubah();
    }//GEN-LAST:event_ubahButtonActionPerformed

    private void hapusButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusButtonActionPerformed
        hapus();
    }//GEN-LAST:event_hapusButtonActionPerformed

    private void cariFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cariFieldKeyReleased
        // Isi tabel disaring setiap tombol keyboard dilepas
        saring();
    }//GEN-LAST:event_cariFieldKeyReleased

    private void kontakTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_kontakTableMouseClicked
        // Klik dua kali pada baris untuk mengubah kontak
        if (evt.getClickCount() == 2 && kontakTable.getSelectedRow() >= 0) {
            ubah();
        }
    }//GEN-LAST:event_kontakTableMouseClicked

    private void keluarItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keluarItemActionPerformed
        dispose();
    }//GEN-LAST:event_keluarItemActionPerformed

    private void tambahItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahItemActionPerformed
        tambah();
    }//GEN-LAST:event_tambahItemActionPerformed

    private void ubahItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ubahItemActionPerformed
        ubah();
    }//GEN-LAST:event_ubahItemActionPerformed

    private void hapusItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusItemActionPerformed
        hapus();
    }//GEN-LAST:event_hapusItemActionPerformed

    private void tentangItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tentangItemActionPerformed
        JOptionPane.showMessageDialog(this,
                "Daftar Kontak\nMini proyek Pertemuan 7 PBO 2", "Tentang",
                JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_tentangItemActionPerformed

    private void isiContoh() {
        model.tambah(new Kontak("Siti Rahmah", "081234567890", "siti@contoh.com",
                Kategori.KAMPUS));
        model.tambah(new Kontak("Budi Santoso", "082112345678", "budi@contoh.com",
                Kategori.TEMAN));
        model.tambah(new Kontak("Ahmad Fauzi", "085398765432", "",
                Kategori.KELUARGA));
        model.tambah(new Kontak("Nur Aisyah", "081355512345", "aisyah@contoh.com",
                Kategori.KAMPUS));
        model.tambah(new Kontak("Rizky Pratama", "087812341234", "rizky@contoh.com",
                Kategori.KERJA));
    }

    private void saring() {
        String kata = cariField.getText().trim();
        if (kata.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            // (?i): huruf besar dan kecil dianggap sama; 0, 1, 2: kolom yang dicari
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(kata), 0, 1, 2));
        }
        perbaruiStatus();
    }

    /**
     * Mengubah nomor baris tampilan menjadi nomor baris model,
     * karena tabel dapat diurutkan dan disaring.
     */
    private int barisTerpilih() {
        int barisTampilan = kontakTable.getSelectedRow();
        if (barisTampilan < 0) {
            return -1;
        }
        return kontakTable.convertRowIndexToModel(barisTampilan);
    }

    private void tambah() {
        Kontak baru = new DialogKontak(this, "Tambah Kontak", null).tampilkan();
        if (baru != null) {
            model.tambah(baru);
            perbaruiStatus();
        }
    }

    private void ubah() {
        int baris = barisTerpilih();
        if (baris < 0) {
            return;
        }
        Kontak hasil = new DialogKontak(this, "Ubah Kontak", model.get(baris)).tampilkan();
        if (hasil != null) {
            model.ubah(baris, hasil);
        }
    }

    private void hapus() {
        int baris = barisTerpilih();
        if (baris < 0) {
            return;
        }
        String nama = model.get(baris).nama();
        int jawab = JOptionPane.showConfirmDialog(this, "Hapus kontak " + nama + "?",
                "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (jawab == JOptionPane.YES_OPTION) {
            model.hapus(baris);
            perbaruiStatus();
        }
    }

    private void perbaruiTombol() {
        boolean adaPilihan = kontakTable.getSelectedRow() >= 0;
        ubahButton.setEnabled(adaPilihan);
        hapusButton.setEnabled(adaPilihan);
        ubahItem.setEnabled(adaPilihan);
        hapusItem.setEnabled(adaPilihan);
    }

    private void perbaruiStatus() {
        statusLabel.setText("Menampilkan " + kontakTable.getRowCount()
                + " dari " + model.getRowCount() + " kontak");
    }

    public static void main(String args[]) {
        FlatLightLaf.setup();

        // Tampilkan form di Event Dispatch Thread
        java.awt.EventQueue.invokeLater(() -> new AplikasiKontak().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel atasPanel;
    private javax.swing.JMenu bantuanMenu;
    private javax.swing.JTextField cariField;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JButton hapusButton;
    private javax.swing.JMenuItem hapusItem;
    private javax.swing.JMenuItem keluarItem;
    private javax.swing.JMenu kontakMenu;
    private javax.swing.JPopupMenu.Separator kontakSeparator;
    private javax.swing.JTable kontakTable;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JLabel statusLabel;
    private javax.swing.JPanel tabelPanel;
    private javax.swing.JScrollPane tabelScroll;
    private javax.swing.JButton tambahButton;
    private javax.swing.JMenuItem tambahItem;
    private javax.swing.JMenuItem tentangItem;
    private javax.swing.JPanel tombolPanel;
    private javax.swing.JButton ubahButton;
    private javax.swing.JMenuItem ubahItem;
    // End of variables declaration//GEN-END:variables
}
